package com.example.deepositbank.Controllers.AccountManager;

import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ViewDetailsController {
    public Label customer_sCode;
    public Label customer_address;
    public Label customer_bank_AcctType;
    public Label gender_type;
    public Label customer_fName;
    public Label customer_Account_type;
    public Label total_balance;
    public Label customer_lName;
    public Label customer_acc_num;
    public Label bank_acc_type;
    public Button exit_btn;
    public Button update_cus_info_btn;
}

