package com.example.deepositbank.Controllers.AccountManager;


import com.example.deepositbank.Models.Customer;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomerCellController implements Initializable {

    public Label fName_lbl;
    public Label lName_lbl;
    public Label sort_code_lbl;
    public Label date_lbl;
    public Button delete_btn;
    public Button view_details_btn;
    public Label aNumber_lbl;

    private final Customer customer;

    public CustomerCellController(Customer customer) {
        this.customer = customer;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        fName_lbl.textProperty().bind(customer.firstNameProperty());
        lName_lbl.textProperty().bind(customer.lastNameProperty());
        sort_code_lbl.textProperty().bind(customer.sortCodeProperty());
        date_lbl.textProperty().bind(customer.dateCreatedProperty().asString());
        view_details_btn.setText("View Details");
        delete_btn.setText("Delete");

        view_details_btn.setOnAction(event -> handleViewDetailsButtonClick());
        delete_btn.setOnAction(event -> handleDeleteButtonClick());
    }

    private void handleViewDetailsButtonClick() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/ViewDetails.fxml"));
        ViewDetailsController controller = new ViewDetailsController();
        loader.setController(controller);
        createStage(loader);
    }

    private void handleDeleteButtonClick() {
        CustomerManager customerManager = new CustomerManager(); // Assuming CustomerManager class exists
        customerManager.deleteCustomer(customer);
        // Perform additional actions if needed after deletion
    }

    private void createStage(FXMLLoader FXMLLoader loader) {
        Stage stage = new Stage();
        stage.setScene(new Scene);
        stage.show();
    }
}