package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Views.AccountManagerMenuOptions;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class AccountManagerMenuController implements Initializable {
    public Button add_new_customer_btn;
    public Button customers_btn;
    public Button deposit_btn;
    public Button logout_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addListeners();
    }
    private void addListeners(){
        add_new_customer_btn.setOnAction(event -> onAddNewCustomer());
        customers_btn.setOnAction(event -> onCustomers());
        deposit_btn.setOnAction(event -> onDeposit());
        logout_btn.setOnAction(event -> onLogout());
    }

    private void onAddNewCustomer(){
        Model.getInstance().getViewFactory().getAccountManagerSelectedMenuItem().set(AccountManagerMenuOptions.ADD_NEW_CUSTOMER);
    }

    private void onCustomers(){
        Model.getInstance().getViewFactory().getAccountManagerSelectedMenuItem().set(AccountManagerMenuOptions.CUSTOMERS);

    }

    private void onDeposit(){
        Model.getInstance().getViewFactory().getAccountManagerSelectedMenuItem().set(AccountManagerMenuOptions.DEPOSIT);
    }
    private void onLogout() {
        // Get Stage
        Stage stage = (Stage) customers_btn.getScene().getWindow();
        // Close the Admin window
        Model.getInstance().getViewFactory().closeStage(stage);
        // Show Login Window
        Model.getInstance().getViewFactory().showLoginWindow();
        // Set Admin Login Success Flag To False
        Model.getInstance().setAccountManagerLoginSuccessFlag(false);
    }
}




