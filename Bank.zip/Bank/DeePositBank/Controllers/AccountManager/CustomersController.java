package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Customer;
import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Views.CustomerCellFactory;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomersController implements Initializable {
    public ListView<Customer> customers_listview;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initCustomersList();
        customers_listview.setItems(Model.getInstance().getCustomers());
        customers_listview.setCellFactory(e -> new CustomerCellFactory());
    }

    private void initCustomersList() {
        if (Model.getInstance().getCustomers().isEmpty()){
            Model.getInstance().setCustomers();
        }
    }
}
