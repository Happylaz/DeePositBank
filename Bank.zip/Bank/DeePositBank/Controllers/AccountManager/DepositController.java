package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Customer;
import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Models.RewardAccount;
import com.example.deepositbank.Models.BasicAccount;
import com.example.deepositbank.Models.IsaAccount;

import com.example.deepositbank.Views.CustomerCellFactory;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class DepositController implements Initializable {

    public TextField aNumber_fld;
    public Button search_btn;
    public ListView<Customer> result_listview;
    public TextField deposit_amount_fld;
    public TextField withdraw_amount_fld;
    public Button deposit_btn;
    public Button withdraw_btn;

    private Customer customer;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        search_btn.setOnAction(event -> onCustomerSearch());
        deposit_btn.setOnAction(event -> onDeposit());
        withdraw_btn.setOnAction(event -> onWithdraw());
    }

    private void onCustomerSearch() {
        ObservableList<Customer> searchResults = Model.getInstance().searchCustomer(aNumber_fld.getText());
        result_listview.setItems(searchResults);
        result_listview.setCellFactory(e -> new CustomerCellFactory());
        customer = searchResults.get(0);
    }

    private void onDeposit() {
        String depositAmountText = deposit_amount_fld.getText();

        if (!depositAmountText.isEmpty()) {
            try {
                double amount = Double.parseDouble(depositAmountText);

                RewardAccount rewardAccount = customer.getRewardAccount();
                IsaAccount isaAccount = customer.getIsaAccount();

                if (rewardAccount != null && isaAccount != null) {
                    double newRewardBalance = rewardAccount.getBalance() + amount;
                    double newIsaBalance = isaAccount.getBalance() + amount;

                    Model.getInstance().getDatabaseDriver().depositRewardAccount(customer.getAccountNumber(), newRewardBalance);
                    Model.getInstance().getDatabaseDriver().depositIsaAccount(customer.getAccountNumber(), newIsaBalance);

                    emptyFields();
                } else {
                    System.out.println("Customer does not have a Reward or Isa Account.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount entered. Please enter a valid number.");
            }
        } else {
            System.out.println("Please enter an amount to deposit");
        }
    }


    private void onWithdraw() {
        String withdrawAmountText = withdraw_amount_fld.getText();

        if (!withdrawAmountText.isEmpty()) {
            try {
                double amount = Double.parseDouble(withdrawAmountText);

                RewardAccount rewardAccount = customer.getRewardAccount();
                BasicAccount basicAccount = customer.getBasicAccount();
                IsaAccount isaAccount = customer.getIsaAccount();

                if (rewardAccount != null && basicAccount != null && isaAccount != null) {
                    double totalBalance = rewardAccount.getBalance() + basicAccount.getBalance() + isaAccount.getBalance();

                    if (amount <= totalBalance) {
                        if (amount <= rewardAccount.getBalance()) {
                            double newRewardBalance = rewardAccount.getBalance() - amount;
                            Model.getInstance().getDatabaseDriver().withdrawFromRewardAccount(customer.getAccountNumber(), newRewardBalance);
                        } else if (amount <= rewardAccount.getBalance() + basicAccount.getBalance()) {
                            double newBasicBalance = basicAccount.getBalance() - (amount - rewardAccount.getBalance());
                            Model.getInstance().getDatabaseDriver().withdrawFromBasicAccount(customer.getAccountNumber(), newBasicBalance);
                        } else {
                            double newIsaBalance = isaAccount.getBalance() - (amount - (rewardAccount.getBalance() + basicAccount.getBalance()));
                            Model.getInstance().getDatabaseDriver().withdrawFromIsaAccount(customer.getAccountNumber(), newIsaBalance);
                        }
                        emptyFields();
                    } else {
                        System.out.println("Insufficient funds across all accounts");
                    }
                } else {
                    System.out.println("Customer does not have one of the required accounts (Reward, Basic, Isa)");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount entered. Please enter a valid number.");
            }
        } else {
            System.out.println("Please enter an amount to withdraw");
        }
    }

    private void emptyFields() {
        aNumber_fld.setText("");
        deposit_amount_fld.setText("");
        withdraw_amount_fld.setText("");
    }}
