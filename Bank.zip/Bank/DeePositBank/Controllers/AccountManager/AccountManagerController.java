package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Model;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class AccountManagerController implements Initializable {

    public BorderPane account_manager_parent;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getViewFactory().getAccountManagerSelectedMenuItem().addListener((observableValue, oldVal, newVal) -> {
            //Add Switch Statement
            switch (newVal){
                case CUSTOMERS -> account_manager_parent.setCenter(Model.getInstance().getViewFactory().getCustomersView());
                case DEPOSIT ->  account_manager_parent.setCenter(Model.getInstance().getViewFactory().getDepositView());
                default -> account_manager_parent.setCenter(Model.getInstance().getViewFactory().getAddNewCustomerView());

            }
        } );
    }
}
