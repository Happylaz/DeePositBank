package com.example.deepositbank.Controllers.Customer;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class ProfileController implements Initializable {
    public Label customerAddress;
    public Label customergender;
    public Label customerbankAcctType;
    public Label userInfoAccounttype;
    public Label customerfName;
    public Label customerlName;
    public Label customerAccounttype;
    public Label bal;
    public Button back_btn;
    

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
