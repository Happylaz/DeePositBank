package com.example.deepositbank.Controllers.Customer;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

import java.net.URL;
import java.util.ResourceBundle;

public class UpdateAcctController implements Initializable {

    public PasswordField old_password_fld;
    public PasswordField new_password_fld;
    public PasswordField confirm_password_fld;
    public Button change_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
