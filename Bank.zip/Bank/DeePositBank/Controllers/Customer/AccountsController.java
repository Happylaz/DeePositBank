package com.example.deepositbank.Controllers.Customer;

import com.example.deepositbank.Models.Customer;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class AccountsController implements Initializable {

    public ListView<Customer>result_listview;
    public Button deposit_btn;
    public TextField deposit_amount_fld;
    public TextField withdraw_amount_fld;
    public Button withdraw_btn;

    public Button add_btn;
    public ChoiceBox<Customer>card_credit_type_selector;
    public DatePicker date_card;
    public TextField cvc_card_fld;
    public TextField amunt_fld;
    public TextField card_nmber_fld;
    public TextField billing_add_fld;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
