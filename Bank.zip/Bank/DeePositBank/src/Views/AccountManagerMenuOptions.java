package com.example.deepositbank.Views;

public enum AccountManagerMenuOptions {

    ADD_NEW_CUSTOMER,
    CUSTOMERS,
    DEPOSIT
}
