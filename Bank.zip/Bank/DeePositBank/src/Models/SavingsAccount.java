package com.example.deepositbank.Models;

import javafx.beans.binding.BooleanExpression;
import javafx.beans.binding.ObjectExpression;
import javafx.beans.value.ObservableValue;

public interface SavingsAccount {
    void applyInterest();
    int getInterestRate();
    void setInterestRate(int rate);
    void deposit(double amount);
    void withdraw(double amount); // Adding the withdrawal method to the interface

    ObservableValue<String> accountNumberProperty();

    BooleanExpression balanceProperty();

    BooleanExpression balanceProperty();

    ObjectExpression<Object> balanceProperty();
}
